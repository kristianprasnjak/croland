# Izvori grafike i fontova u `mini games media/`

Ovdje je samo grafika preuzeta s interneta, i sva je **CC0** (javno dobro, slobodno i za komercijalnu upotrebu, bez obveze navođenja autora).
Izuzetak su fontovi, koji su pod licencom **SIL Open Font License 1.1**. Ona dopušta komercijalnu upotrebu i ugradnju u aplikaciju; zabranjuje samo prodaju samog fonta.

Izvorni paketi čuvaju se u `../../kenney/<paket>/` (uz njihov `License.txt`). Listovi za igre slažu se iz njih skriptom `node _sadrzaj/sprajtovi.js`.

| datoteka | izvor | licenca | preuzeto |
|---|---|---|---|
| `ui-okvir.png`, `ui-okvir-tamni.png`, `ui-okvir-plavi.png` | Kenney — UI Pack: Pixel Adventure · https://kenney.nl/assets/ui-pack-pixel-adventure | CC0 | 26. 9. 2026. |
| `skladiste.png` (pod, regal, vrata, radnik) | Kenney — Tiny Dungeon · https://kenney.nl/assets/tiny-dungeon | CC0 | 26. 9. 2026. |
| `labirint.png` (zid, pod, duh) | Kenney — Tiny Dungeon | CC0 | 26. 9. 2026. |
| `portal.png` (lik) | Kenney — Tiny Dungeon | CC0 | 26. 9. 2026. |
| `zmija.png` (trava, kamen) | Kenney — Tiny Town · https://kenney.nl/assets/tiny-town | CC0 | 26. 9. 2026. |
| `konoba-gosti.png` | Kenney — Roguelike Characters · https://kenney.nl/assets/roguelike-characters | CC0 | 26. 9. 2026. |
| `kenney-rogue.png`, `kenney-urban.png` (Grad) | Kenney — Roguelike RPG Pack, Roguelike Modern City | CC0 | kolovoz 2026. |
| `font-pixelify-sans.ttf` | Pixelify Sans · https://github.com/google/fonts/tree/main/ofl/pixelifysans | OFL 1.1 | 26. 9. 2026. |
| `font-nunito.ttf` | Nunito · https://github.com/google/fonts/tree/main/ofl/nunito | OFL 1.1 | 26. 9. 2026. |
| `font-geist-latin-*.woff2`, `font-geist-latin-ext-*.woff2` (400, 600, 700) | Geist (Vercel) · https://github.com/vercel/geist-font, preko paketa @fontsource/geist 5.3.0 | OFL 1.1 | 11. 10. 2026. |
| `font-geist-pixel-latin-400.woff2`, `font-geist-pixel-latin-ext-400.woff2` | Geist Pixel (Vercel) · https://github.com/vercel/geist-font, preko paketa @fontsource/geist-pixel | OFL 1.1 | 11. 10. 2026. |

Preuzeti su i ovi paketi, ali se trenutno ne koriste; ostaju u `kenney/` kao rezerva:
- Pixel Platformer · https://kenney.nl/assets/pixel-platformer
- Pixel Platformer Food Expansion · https://kenney.nl/assets/pixel-platformer-food-expansion

## Nije preuzeto s interneta

| datoteka | porijeklo |
|---|---|
| Blobby, kutija, zvijezda, žeton i dijelovi zmije u `labirint.png`, `skladiste.png`, `zmija.png`, `blobby.png` | ručno nacrtano u `_sadrzaj/sprajtovi.js` |
| `portal-rak.png` | ručno nacrtano u `_sadrzaj/sprajtovi.js` |
| `tvr-hrana-*.png` (10 kom) | smanjene kopije ilustracija iz `slike/` |
| `vlak-*.png` | vlastite slike |
| Gemini slike (`tvr-*`, `konoba-interijer`, `vlak-kolodvor`, `portal-pozadina-*`, `obrana-nebo*`) | izrađuje korisnik, vidi `../MINI-gemini-promptovi.md` |
| `konoba-gost-01.webp` … `-12.webp` | Gemini (Nano Banana 2.1), `redizajn/konoba/generiraj.js`, 11. 10. 2026.; izrezani portreti |
| `konoba/*.png` (38 jela, 38 `-mini`, 12 gostiju × 3 izraza) | Gemini (Nano Banana 2.1), `redizajn/konoba-pixel/popis.json`, 11. 10. 2026.; svedeno na pravi pixel art s `redizajn/pikseli.py` (jela 32×32, gosti 40×40, zajednička paleta) |
| `konoba/zid.png`, `drvo.png`, `ploca.png`, `rep.png` | vlastite pixel teksture, izrađene za ovu igru |
